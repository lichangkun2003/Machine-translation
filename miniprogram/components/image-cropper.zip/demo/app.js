App({
  onLaunch: function () {

  },
  globalData:{}
})
