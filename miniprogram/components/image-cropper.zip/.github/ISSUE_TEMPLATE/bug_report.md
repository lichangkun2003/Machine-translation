---
name: 提交bug
about: 按照这个模板写
title: ''
labels: ''
assignees: ''

---

对应工具或者iOS或者Andriod的版本号

微信版本号

代码截图

重现步骤

期待的行为

实际的行为
